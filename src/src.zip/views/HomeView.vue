<template>
  <HeroSection />
  <ServicesSection />
  <ToursSection />
</template>

<script setup>
import HeroSection from '@/components/home/HeroSection.vue'
import ServicesSection from '@/components/home/ServicesSection.vue'
import ToursSection from '@/components/home/ToursSection.vue'
</script>
