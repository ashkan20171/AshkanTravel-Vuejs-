<template>
  <ToursSection />
</template>

<script setup>
import ToursSection from '@/components/home/ToursSection.vue'
</script>
