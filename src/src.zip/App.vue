<template>
  <AppHeader />
  <main class="page">
    <RouterView />
  </main>
</template>

<script setup>
import AppHeader from '@/components/layout/AppHeader.vue'
</script>
